import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:mealapp/models/meal.dart';

class FavouriteMealsNotifier extends StateNotifier<List<Meal>>{
  FavouriteMealsNotifier():super([]);
  bool toggleMealFavouriteStatus(Meal meal){
    final mealIsFavourite = state.contains(meal);
    // state = [];
    if(mealIsFavourite){
      print("one");
      print(state);
      state = state.where((m) => m.id != meal.id).toList();
      return false;
    }else{
      // state.add(meal);
      state = [...state, meal];
      print("two");
      print(state);
      return true;
    }
  }
}

final favouriteMealsProvider = StateNotifierProvider<FavouriteMealsNotifier,List<Meal>>((ref) {
      return FavouriteMealsNotifier();
  },);