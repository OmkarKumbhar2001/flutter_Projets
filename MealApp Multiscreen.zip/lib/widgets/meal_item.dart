import 'package:flutter/material.dart';
import 'package:mealapp/models/meal.dart';
import 'package:mealapp/widgets/meal_item_trait.dart';
import 'package:transparent_image/transparent_image.dart';

class MealItem extends StatelessWidget {
  const MealItem({super.key, required this.meal,required this.goMealDetailPage});
  final void Function() goMealDetailPage;
  final Meal meal;
  String get complexityText{
    return meal.complexity.name[0].toUpperCase()+meal.complexity.name.substring(1);
  }
  String get affordability{
    return meal.affordability.name[0].toUpperCase()+meal.affordability.name.substring(1);
  }
  @override
  Widget build(BuildContext context) {
    return Card(
      margin:const EdgeInsets.all(8),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
      clipBehavior: Clip.hardEdge,
      elevation: 2,//drop shadow
      child: InkWell(
        onTap: goMealDetailPage,
        child: Stack(
          children: [
            FadeInImage(
              placeholder: MemoryImage(kTransparentImage),
              image: NetworkImage(meal.imageUrl),
              fit: BoxFit.cover,
              height: 200,
              width: double.infinity,
              imageErrorBuilder: (context, error, stackTrace) {
                return const Center(
                  child: SizedBox(
                  height: 200,
                    child:Text("Img Not Found or no internet",style: TextStyle(color: Colors.white),),
                  ),
                );
              },
            ), //img fetchedd from internet
            Positioned(
                bottom: 0,
                // top: 0,if i added top here my black color get full width
                left: 0,
                right: 0,
                child: Container(
                  color: Colors.black54,
                  padding:
                      const EdgeInsets.symmetric(horizontal: 24, vertical: 6),
                  child: Column(children: [
                    Text(
                      meal.title,
                      maxLines: 2,
                      textAlign: TextAlign.center,
                      softWrap: true,
                      overflow: TextOverflow.ellipsis,//long text ends with ... dots
                      style: const TextStyle(fontSize: 20,fontWeight: FontWeight.bold,
                      color: Colors.white
                      ),
                    ),
                    const SizedBox(
                      height: 12,
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        MealItemTrait(icon: Icons.schedule, label:'${meal.duration} min' ),
                        const SizedBox(width: 12,),
                        MealItemTrait(icon: Icons.work, label:complexityText  ),
                        const SizedBox(width: 12,),
                        MealItemTrait(icon: Icons.attach_money, label:affordability  ),
                      ],
                    )
                  ]),
                ))
          ],
        ), //Stack this is widget that add one on one widget not one by one
      ),
    );
  }
}
