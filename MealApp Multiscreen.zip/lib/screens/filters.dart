import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:mealapp/providers/filters_provider.dart';
enum Filter {
  gultenFree,
  lactoseFree,
  vegetarian,
  vegan,
}

class FiltersScreen extends ConsumerWidget {
  const FiltersScreen({super.key});



  @override
  Widget build(BuildContext context,WidgetRef ref) {
    final activeFilters=ref.watch(filtersProvider);
    return Scaffold(
      appBar: AppBar(
        title: const Text("Add Multiple Filter"),
      ),
      // drawer: MainDrawer(onSelectScreen: (identifier){
      //   Navigator.of(context).pop();
      //   if(identifier=="meals"){
      //     Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (ctx)=>const TabsScreen()));
      //   }
      // }),
      body: Column(
          children: [
            SwitchListTile(
              value: activeFilters[Filter.gultenFree]!,
              onChanged: (isChecked){
               ref.read(filtersProvider.notifier).setFilter(Filter.gultenFree, isChecked);

              },
              title: Text(
                "Gulten-Free",
                style: Theme.of(context)
                    .textTheme
                    .titleLarge!
                    .copyWith(color: Theme.of(context).colorScheme.onBackground),
              ),
              subtitle: Text("without milk",style: Theme.of(context)
                  .textTheme
                  .labelMedium!
                  .copyWith(color: Theme.of(context).colorScheme.onBackground), ),
              activeColor:Theme.of(context).colorScheme.tertiary ,
              contentPadding:const EdgeInsets.only(left: 34,right: 22),
            ),
            SwitchListTile(
              value:activeFilters[Filter.lactoseFree]!,
              onChanged: (isChecked){
                ref.read(filtersProvider.notifier).setFilter(Filter.lactoseFree, isChecked);

              },
              title: Text(
                "Lactose-Free",
                style: Theme.of(context)
                    .textTheme
                    .titleLarge!
                    .copyWith(color: Theme.of(context).colorScheme.onBackground),
              ),
              subtitle: Text("Lactose-Free",style: Theme.of(context)
                  .textTheme
                  .labelMedium!
                  .copyWith(color: Theme.of(context).colorScheme.onBackground), ),
              activeColor:Theme.of(context).colorScheme.tertiary ,
              contentPadding:const EdgeInsets.only(left: 34,right: 22),
            ),
            SwitchListTile(
              value: activeFilters[Filter.vegetarian]!,
              onChanged: (isChecked){
                ref.read(filtersProvider.notifier).setFilter(Filter.vegetarian, isChecked);
              },
              title: Text(
                "Vegetarian",
                style: Theme.of(context)
                    .textTheme
                    .titleLarge!
                    .copyWith(color: Theme.of(context).colorScheme.onBackground),
              ),
              subtitle: Text("only Vegetarian",style: Theme.of(context)
                  .textTheme
                  .labelMedium!
                  .copyWith(color: Theme.of(context).colorScheme.onBackground), ),
              activeColor:Theme.of(context).colorScheme.tertiary ,
              contentPadding:const EdgeInsets.only(left: 34,right: 22),
            ),
            SwitchListTile(
              value:  activeFilters[Filter.vegan]!,
              onChanged: (isChecked){
                ref.read(filtersProvider.notifier).setFilter(Filter.vegan, isChecked);

              },
              title: Text(
                "Vegan",
                style: Theme.of(context)
                    .textTheme
                    .titleLarge!
                    .copyWith(color: Theme.of(context).colorScheme.onBackground),
              ),
              subtitle: Text("only Vegan",style: Theme.of(context)
                  .textTheme
                  .labelMedium!
                  .copyWith(color: Theme.of(context).colorScheme.onBackground), ),
              activeColor:Theme.of(context).colorScheme.tertiary ,
              contentPadding:const EdgeInsets.only(left: 34,right: 22),
            ),
          ],
        )
    );
  }
}
