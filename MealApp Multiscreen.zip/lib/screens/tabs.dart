import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:mealapp/models/meal.dart';
import 'package:mealapp/providers/favourites_provider.dart';
import 'package:mealapp/providers/filters_provider.dart';
import 'package:mealapp/providers/meals_provider.dart';
import 'package:mealapp/screens/categories.dart';
import 'package:mealapp/screens/filters.dart';
import 'package:mealapp/screens/meals.dart';
import 'package:mealapp/widgets/main_drawer.dart';

const kInitialFilters ={
  Filter.gultenFree:false,
  Filter.lactoseFree:false,
  Filter.vegan:false,
  Filter.vegetarian:false,

};
//if here Stateless widget is present we have to replace with ConsumerWidget
class TabsScreen extends ConsumerStatefulWidget {
  const TabsScreen({super.key});

  @override
  ConsumerState<TabsScreen> createState() {
    return _TabsScreenState();
  }
}

class _TabsScreenState extends ConsumerState<TabsScreen> {
  int _seletedPageIndex = 0;

  void _selectPage(int index) {
    setState(() {
      _seletedPageIndex = index;
    });
  }

  void _setScreen(String identifier) async{
    Navigator.of(context).pop();
    if (identifier == "filters") {
      // Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (ctx)=>const FiltersScreen()));//it removes back button on FilterScreen
     await Navigator.of(context)
          .push<Map<Filter,bool>>(MaterialPageRoute(builder: (ctx) => const FiltersScreen()));
    } else {
      setState(() {
        _seletedPageIndex = 0;
      });
    }
  }

  @override
  Widget build(BuildContext context) {

    final availableMeals = ref.watch(filderdMealsProvider);
    Widget activePage =
        CategoriesScreen(availableMeals: availableMeals);
    var ActivePageTitle = "Categories";
    if (_seletedPageIndex == 1) {
      final favouriteMeal = ref.watch(favouriteMealsProvider);
      activePage = MealsScreen(
          meals: favouriteMeal);
      ActivePageTitle = "Favourites...";
    }
    return Scaffold(
      appBar: AppBar(
        title: Text(ActivePageTitle),
      ),
      drawer: MainDrawer(onSelectScreen: _setScreen),
      body: activePage,
      bottomNavigationBar: BottomNavigationBar(
        onTap: _selectPage,
        currentIndex: _seletedPageIndex,
        items: const [
          BottomNavigationBarItem(
              icon: Icon(Icons.set_meal), label: "Categories"),
          BottomNavigationBarItem(icon: Icon(Icons.star), label: "Favourites"),
        ],
      ),
    );
  }
}
