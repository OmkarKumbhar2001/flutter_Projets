import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:mealapp/models/meal.dart';
import 'package:mealapp/providers/favourites_provider.dart';
import 'package:transparent_image/transparent_image.dart';

class MealDetails extends ConsumerWidget{
  const MealDetails({super.key,required this.meal});
  final Meal meal;

  @override
  Widget build(BuildContext context,WidgetRef ref) {
    final favouriteMeals=ref.watch(favouriteMealsProvider);
    final isFavourite=favouriteMeals.contains(meal);
    return Scaffold(
      appBar: AppBar(
        title: Text(meal.title),
        actions: [
          IconButton(
            onPressed: (){
              final wasAdded = ref.read(favouriteMealsProvider.notifier).toggleMealFavouriteStatus(meal);
              ScaffoldMessenger.of(context).clearSnackBars();
              ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                duration: const Duration(seconds: 2),
                content: Text(wasAdded ? "Meal added ":"Meal remove"),
              ));
            },
            icon:  Icon( isFavourite ? Icons.star:Icons.star_border_outlined),
          ),
        ],
      ),
      body: SingleChildScrollView(
        child: Column(
         children: [
           FadeInImage(
             placeholder: MemoryImage(kTransparentImage),
             image: NetworkImage(meal.imageUrl),
             fit: BoxFit.cover,
             height: 200,
             width: double.infinity,
             imageErrorBuilder: (context, error, stackTrace) {
               return const Center(
                 child: SizedBox(
                   height: 200,
                   child:Text("Img Not Found or no internet",style: TextStyle(color: Colors.white),),
                 ),
               );
             },
           ),
           const SizedBox(height: 14),
            Text("Ingredients",style: Theme.of(context).textTheme.titleLarge!.copyWith(
             color: Theme.of(context).colorScheme.primary,fontWeight: FontWeight.bold
           ),),
           const SizedBox(height: 14),
           for(final ingredients in meal.ingredients)
               Text(ingredients,style: Theme.of(context).textTheme.bodyMedium!.copyWith(
                   color: Theme.of(context).colorScheme.onBackground)),
           const SizedBox(height: 24),
           Text("Steps",style: Theme.of(context).textTheme.titleLarge!.copyWith(
               color: Theme.of(context).colorScheme.primary,fontWeight: FontWeight.bold
           ),),
           const SizedBox(height: 14),
           for(final step in meal.steps)
             Padding(
               padding: const EdgeInsets.symmetric(horizontal: 12,vertical: 8),
               child: Text(step,
                   textAlign: TextAlign.center,
                   style: Theme.of(context).textTheme.bodyMedium!.copyWith(
                   color: Theme.of(context).colorScheme.onBackground)),
             ),

         ],
        ),
      ),
    );
  }

}